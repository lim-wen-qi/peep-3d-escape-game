using UnityEngine;

public class CluePaper : MonoBehaviour
{
    [TextArea(3, 5)]
    public string clueMessage;  // Write the clue text in Inspector
}
