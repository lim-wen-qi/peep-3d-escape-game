using UnityEngine;

public class PuzzleCube : MonoBehaviour
{
    [Header("Book Settings")]
    public int bookCount;                     // Number of books this cube represents
    public Vector3 clickMove = new Vector3(0, 0, -0.015f); // How much cube moves on click

    [HideInInspector]
    public bool isClicked = false;            // Track if player clicked this cube

    private Vector3 originalPosition;         // Store initial position for reset

    void Start()
    {
        originalPosition = transform.position;
    }

    // Detect mouse clicks
    void OnMouseDown()
    {
        Debug.Log("Cube clicked: " + gameObject.name);

        BookPuzzleManager manager = FindObjectOfType<BookPuzzleManager>();
        if (manager != null)
        {
            manager.CubeClicked(this);       // Notify manager
        }
        else
        {
            Debug.LogWarning("Puzzle Manager not found in scene!");
        }
    }

    // Called by manager when click is valid
    public void ClickCube()
    {
        if (!isClicked)
        {
            transform.position += clickMove; // Move cube slightly along Z
            isClicked = true;
            Debug.Log(gameObject.name + " moved!");
        }
    }

    // Reset cube if sequence fails
    public void ResetCube()
    {
        transform.position = originalPosition;
        isClicked = false;
    }
}
