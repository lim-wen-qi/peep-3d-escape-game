using UnityEngine;

public class Candle : MonoBehaviour
{
    void Awake()
    {
        Light[] lights = GetComponentsInChildren<Light>();
        foreach (Light l in lights)
            l.enabled = false;

        ParticleSystem[] flames = GetComponentsInChildren<ParticleSystem>();
        foreach (ParticleSystem f in flames)
            f.Stop();
    }
}